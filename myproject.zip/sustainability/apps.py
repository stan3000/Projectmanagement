from django.apps import AppConfig


class SustainabilityConfig(AppConfig):
    name = 'sustainability'
