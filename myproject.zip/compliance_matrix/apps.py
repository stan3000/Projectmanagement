from django.apps import AppConfig


class ComplianceMatrixConfig(AppConfig):
    name = 'compliance_matrix'
