from django.apps import AppConfig


class FacilitiesConfig(AppConfig):
    name = 'facilities'
