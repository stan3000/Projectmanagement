from django.apps import AppConfig


class ManagementConfig(AppConfig):
    name = 'management'

#===============An ADDITION=======TESTING APP PAGE===================





#===============SUSTAINABILITY PAGE===================

